using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Club : MonoBehaviour
{
    public float score = 0;
    public Rigidbody ballrb;
    public float force = 1.5f;
    public GameObject ball;
    public GameObject camera;
    public GameObject club;
    public MeshRenderer clubmr;
    float power=0;
    bool is_increase=true;
    
    void Update()
    {
        if(ball.transform.position.y<-10){
            SceneManager.LoadScene("SampleScene");
        }
        transform.position = ball.transform.position;
        if(Input.GetKey("left")){
            transform.localEulerAngles -= new Vector3(0,60,0) * Time.deltaTime;
            camera.transform.localEulerAngles -= new Vector3(0,60,0) * Time.deltaTime;
        }
        if(Input.GetKey("right")){
            transform.localEulerAngles += new Vector3(0,60,0) * Time.deltaTime;
            camera.transform.localEulerAngles += new Vector3(0,60,0) * Time.deltaTime;
        }
        if(Input.GetKey("space")){
            if(is_increase==true){
                power+=Time.deltaTime*3;
                if(power>5){
                    is_increase=false;
                    power=5;
                }
            }else{
                power-=Time.deltaTime*3;
                if(power<0.05){
                    is_increase=true;
                    power=0.05f;
                }
            }
            clubmr.enabled=true;
            club.transform.localScale = new Vector3(0.5f, 0.5f, power);
        }else{
            ballrb.AddForce(transform.forward*force*power, ForceMode.Impulse);
            if(power!=0){
                score+=1;
                GameObject.Find("Hit").GetComponent<TextMeshPro>().text = "Hits : "+score.ToString();
            }
            power = 0;
            clubmr.enabled=false;
        }
    }
}
