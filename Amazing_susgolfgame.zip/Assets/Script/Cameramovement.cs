using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cameramovement : MonoBehaviour
{
    
    public GameObject ball;

    void LateUpdate()
    {
        transform.position = ball.transform.position;
    }
}
